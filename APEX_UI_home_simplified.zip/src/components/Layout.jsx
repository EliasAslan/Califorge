import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import BottomNav from '@/components/BottomNav';

export default function Layout() {
  const { pathname } = useLocation();
  // Hide bottom nav during an active workout session for focus
  const inSession = pathname === '/workout' || pathname === '/summary' || pathname.startsWith('/workout/');

  return (
    <div className="min-h-full">
      <main className={`mx-auto max-w-[620px] min-h-screen ${inSession ? '' : 'pb-[calc(7rem+env(safe-area-inset-bottom))]'}`}>
        <Outlet />
      </main>
      {!inSession && <BottomNav />}
    </div>
  );
}